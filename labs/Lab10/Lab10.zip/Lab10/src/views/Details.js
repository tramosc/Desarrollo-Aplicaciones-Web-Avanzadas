import React from 'react';

const Details = () => {
    return (<div>
        <h1>Este estos son los detalles</h1>
    </div>);
};

export default Details;